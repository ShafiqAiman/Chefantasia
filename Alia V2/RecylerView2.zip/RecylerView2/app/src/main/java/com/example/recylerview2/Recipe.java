package com.example.recylerview2;

public class Recipe {
    private String title, imageURL;
    private float rating;

    public Recipe(){

    }
    public Recipe(String title, String imageURL, float rating) {
        this.title = title;
        this.imageURL = imageURL;
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public String getImageURL() {
        return imageURL;
    }

    public float getRating() {
        return rating;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }
}
